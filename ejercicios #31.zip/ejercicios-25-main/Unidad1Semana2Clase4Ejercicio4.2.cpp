// Ejercicio 4.2 del Periodo I
#include <iostream>
using namespace std;

int main (){
	int producto = 3;
	while ( producto <= 100 ){
	producto = 3 * producto;
	}
	cout << "Producto es: " << producto;
}