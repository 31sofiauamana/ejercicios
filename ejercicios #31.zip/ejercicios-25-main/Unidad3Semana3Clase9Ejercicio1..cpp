// Ejercicio 1 del Periodo III (SEMANA 3)
#include <iostream>
using namespace std;

int main()
{
	int numero;
	do
	{
		cout <<  "Ingrese un numero ";
		cin >> numero;
	}
	while(numero <= 100);
	system("PAUSE");
	return 0;
}